const videoId = window.location.pathname.split("/")[2];

window.location.href = `https://www.nicovideo.jp/watch_tmp/${videoId}`;



// https://www.nicovideo.jp/watch/sm9
